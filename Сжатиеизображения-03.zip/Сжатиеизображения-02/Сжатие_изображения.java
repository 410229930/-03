package com.wonsikin.pic;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Сжатие_изображения {
    private File file = null; //файловый объект
    private String inputDir;  //Исходный путь к изображению
    private String outputDir; //Сгенерировать путь графа
    private String inputFileName; //Оригинальное название изображения
    private String outputFileName; //Сгенерировать имя графика Сгенерировать имя графика
    private int outputWidth = 100;  //Ширина сгенерированного изображения по умолчанию
    private int outputHeight = 100; //Высота сгенерированного изображения по умолчанию
    private boolean proportion = true; //Нужно ли масштабировать

    public Сжатие_изображения {
        //Инициализировать переменные
        inputDir = "";
        outputDir = "";
        inputFileName = "";
        outputFileName = "";
        outputWidth = 100;
        outputHeight = 100;

    }
    public void setInputDir(String inputDir) {
        this.inputDir = inputDir;
    }

    public void setOutputDir(String outputDir) {
        this.outputDir = outputDir;
    }

    public void setInputFileName(String inputFileName) {
        this.inputFileName = inputFileName;
    }

    public void setOutputFileName(String outputFileName) {
        this.outputFileName = outputFileName;
    }

    public void setOutputWidth(int outputWidth) {
        this.outputWidth = outputWidth;
    }

    public void setOutputHeight(int outputHeight) {
        this.outputHeight = outputHeight;
    }

    public void setWidthAndHeight(int width, int height){
        this.outputWidth = width;
        this.outputHeight = height;
    }
    /**
     * получить размер изображения
     * Путь входящего параметра: путь к изображению
     * */
    public long getPicSize(String path){
        file = new File(path);
        return file.length();
    }
    /*
     *обработка изображений
     * **/
    public String compressPic(){
        try{
            //Получите исходное изображение
            file = new File(inputDir + inputFileName);
            if(!file.exists()){
                return "";
            }
            Image img = ImageIO.read(file);
            //Определить, правильный ли формат изображения
            if (img.getWidth(null) == -1 ){
                System.out.println("Can't read,retry!"+ "<BR>");
                return "No";
            } else {
                int newWidth;
                int newHeight;
                // Определите, нужно ли масштабировать пропорционально
                if(this.proportion == true ){
                    double rate1 = ((double) img.getWidth(null)) / (double) outputWidth + 0.1;
                    double rate2 = ((double) img.getHeight(null)) / (double) outputHeight + 0.1;
                    double rate = rate1 > rate2 ? rate1 : rate2;
                    newWidth = (int) (((double) img.getWidth(null))/rate);
                    newHeight = (int) (((double) img.getHeight(null))/rate);
                } else{
                    newWidth = img.getWidth(null);
                    newHeight = img.getHeight(null);
                }
                BufferedImage tag = new BufferedImage((int) newWidth, (int) newHeight, BufferedImage.TYPE_INT_RGB);
                /*
                 * Алгоритм миниатюры mage.SCALE_SMOOTH генерирует плавность миниатюрного изображения.
                 * Приоритет выше скорости, качество генерируемого изображения лучше, но скорость низкая
                 */
                tag.getGraphics().drawImage(img.getScaledInstance(newWidth,newHeight,Image.SCALE_SMOOTH), 0,0,null);
                FileOutputStream out = new FileOutputStream(outputDir + outputFileName);
                /* JPEGImageEncoder可适用于其他图片类型的转换 */
                JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
                encoder.encode(tag);
                out.close();
            }

        } catch (IOException e){
            e.printStackTrace();

        }
        return "OK";

    }
    public String compressPic(String inputDir, String outputDir, String inputFileName, String outputFileName) {
        this.inputDir = inputDir;
        this.outputDir = outputDir;
        this.inputFileName = inputFileName;
        this.outputFileName = outputFileName;
        return compressPic();
    }
    public String compressPicDemo(String inputDir, String outputDir, String inputFileName, String outputFileName, int outputWidth, int outputHeight, boolean proportion) {
        this.inputDir = inputDir;
        this.outputDir = outputDir;
        this.inputFileName = inputFileName;
        this.outputFileName = outputFileName;
        setWidthAndHeight(outputWidth,outputHeight);
        this.proportion = proportion;

        return compressPic();

    }
    public static void main(String[] args){
        CompressPicDemo mypic = new CompressPicDemo();
        System.out.println("Start");
        mypic.compressPicDemo("C:\\","C:\\test\\","1.jpg","r2.jpg",1366,960, false);
    }
}
